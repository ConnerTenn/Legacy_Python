# CPT: Insert Game Title Here
# Authors : Conner & Aniekan
# Course: ICS-3U
# Date: 2016-06-01

import pygame
from math import *

# -------- Colors Palet/Constants --------
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
BLUE = (0,0,255)
GREEN = (0,255,0)
GREY = (100,100,100)

PI = 3.14159265358979323
TAU = 2*PI
#Not Python 2.x Compatable: Change chr to uni_char
ESC=chr(pygame.K_ESCAPE); U_ARROW = chr(pygame.K_UP); D_ARROW = chr(pygame.K_DOWN); R_ARROW = chr(pygame.K_RIGHT); L_ARROW = chr(pygame.K_LEFT); SPACE = chr(pygame.K_SPACE)

def createPath(folder,frameType,weapon,numFrames):
    result = []
    for i in range(0,numFrames,1):
        path = folder+"/"+frameType+"/survivor-"+frameType+"_"+weapon+"_"+str(i)+".png"
        result.append(path)
    return result

p1_idle = createPath("player1","idle","shotgun", 20)
p1_move = createPath("player1","move","shotgun", 20)
p1_shoot = createPath("player1","shoot","shotgun",3)

p2_idle = createPath("player2","idle","handgun", 20)
p2_move = createPath("player2","move","handgun", 20)
p2_shoot = createPath("player2","shoot","handgun",3)

# ============ Classes and Function ==============

def degToRad(deg):
  rad = deg / 360.0 * TAU
  return rad

def radTodeg(rad):
  deg = rad / TAU * 360.0
  return deg

class Player(pygame.sprite.Sprite):
    def __init__(self, pos, p_idle, p_move, p_shoot):
        #Python 2.x
        #super.(Player,self)__init__()
        #Python 3.x
        super().__init__()
        self.absRotation = 0.0 #initially facing right
        self.speed = 0.0
        self.weapon = "default"
        self.ammo = 0 
        self.maxAmmo = 0
        self.idleFrames = []
        self.walkingFrames = []
        self.shootingFrames = []
        # Number of frames between each shot
        self.fireTimeout = 10
        
        
        self.image = pygame.Surface([100,100])
        #self.image.fill(WHITE)
        #self.image.set_colorkey(WHITE)
        #pygame.draw.ellipse(self.image,colour,[0,0,30,30])
        #pygame.draw.line(self.image, GREEN, [15, 15], [15, 0], 2)
        #self.image.blit(pygame.image.load("player.png").convert(), [0, 0])
      
        
        # Using paths to create and convert images
        for path in p_idle:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(BLACK)
            self.idleFrames.append(frame)
        for path in p_move:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(BLACK)
            self.idleFrames.append(frame)
        for path in p_shoot:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(BLACK)
            self.idleFrames.append(frame)
        self.image.blit(self.idleFrames[0], [0, 0])
        
        self.rect = self.image.get_rect()
        self.rect.x = pos[0]
        self.rect.y = pos[1]

    #Tenn
    def move(self, rotation):
        self.rect.x+=cos(rotation)*self.speed
        self.rect.y+=sin(rotation)*self.speed
        
    # Aniekan 
    # @param: angle of rotation (radians)
    def rotate(self, rotation):
        self.absRotation += rotation
        deg = radToDeg(rotation)
        self.image = pygame.transform.rotate(self.image, deg)
        
    #Tenn
    def shoot(self):
        newBullet = Bullet(self.pos[0], self.pos[1], self.rotation)
        return newBullet

class Drops:
    #Tenn
    def __init__(self):
        #Python 2.x
        #super.(Player,self)__init__()
        #Python 3.x
        super().__init__()
        
        self.image = pygame.Surface([10,10])
        self.image.blit(pygame.image.load("bullet.png").convert(), [0, 0])
        self.rect = self.image.get_rect()
        
'''      
# Create two, more specific player classes

class Player1(Player):
    def __init__ (self):
        super().__init__()
        self.idleFrames = []
        self.walkingFrames = []
        self.shootingFrames = []
        # Using paths to create and convert images
        for path in p1_idle:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(BLACK)
            self.idleFrames.append(frame)
        for path in p1_move:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(BLACK)
            self.idleFrames.append(frame)
        for path in p1_shoot:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(BLACK)
            self.idleFrames.append(frame)
        self.image.blit(self.idleFrames[0], [0, 0])

class Player2(Player):
    def __init__ (self):
        super().__init__()
        self.idleFrames = []
        self.walkingFrames = []
        self.shootingFrames = []
        # Using paths to create amd convert images
        for path in p2_idle:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(WHITE)
            self.idleFrames.append(frame)
        for path in p2_move:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(WHITE)
            self.idleFrames.append(frame)
        for path in p2_shoot:
            frame = pygame.image.load(path).convert()
            frame.set_colorkey(WHITE)
            self.idleFrames.append(frame)
        self.image.blit(self.idleFrames[0], [0, 0])
        '''
# Aniekan     
class Bullet(pygame.sprite.Sprite):
    # @param: x, y (integers) position of the bullet
    # @param: width, height (integers) dimensions of the bullet
    
    # Aniekan
    def __init__(self,x,y,rotation):
        #Python 2.x
        #super.(Player,self)__init__()
        #Python 3.x
        super().__init__()
        self.image = pygame.Surface([10,10])
        self.image.fill(WHITE)
        self.image.set_colorkey(WHITE)
        # Drawing the visible image of the circle
        pygame.draw.ellipse(self.image, BLACK, [0,0,10,10])
        # Set top-left corner of bullet to passed in location
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
    # Aniekan
    def ricochet(sprite):
        pass
    # Aniekan
    def checkCol(sprites):
        pass
    
    
    
# Aniekan
class Walls(pygame.sprite.Sprite):
    # @param: x, y (integers) position of wall on the screen
    # @param: width, height (integers) dimensions of the wall
    # Aniekan
    def __init__(self, x, y, width, height):
        #Initializing the parent class
        #Python 2.x
        #super.(Player,self)__init__()
        #Python 3.x
        super().__init__()
        # 
        self.image = pygame.Surface((width,height)) # Setting the size of the wall
        self.image.fill(GREY)
        self.rect = self.image.get_rect()
        # Make the top left corner the passed in location
        self.rect.x = x
        self.rect.y = y


# --------------- Main Class --------------

class Main:
    #Tenn
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode([1200, 600])
        pygame.display.set_caption("Game")
        pygame.mouse.set_visible(True)
        self.clock = pygame.time.Clock()

        #Fix is needed for python 2.x
        #Player1 w,s,a,d, t,y,SPACE
        #Player2 U,D,L,R, 5,6,0
        self.pressed = {"q":False, ESC:False, \
            "w":False, "s":False, "a":False, "d":False, "t":False, "y":False, SPACE:False, \
            U_ARROW:False, D_ARROW:False, L_ARROW:False, R_ARROW:False, "5":False, "6":False, "0":False}
        #self.pressed2 = []
        
        self.allSprites = pygame.sprite.Group()
        self.bulletSprites = pygame.sprite.Group()
        self.wallSprites = pygame.sprite.Group()
        self.playerSprites = pygame.sprite.Group()
        
        self.play = True
    
    # Aniekan    
    def initLevel(self):
        
        self.player1 = Player([0, 0], p1_idle, p1_move, p1_shoot)
        self.allSprites.add(self.player1)
        self.playerSprites.add(self.player1)
        self.player2 = Player([500, 0], p2_idle, p2_move, p2_shoot)
        self.allSprites.add(self.player2)
        self.playerSprites.add(self.player2)
        
        Rooms = []
        walls1 = [[0,0,10,260],[0,340,10,260],[10,0,550,10],[10,590,550,10],
                    [650,0,550,10],[1190,10,10,250],[1190,350,10,250],[650,590,540,10],
                    [0,260,100,10],[0,340,100,10],[90,90,10,100],[90,410,10,100],
                    [90,90,400,10],[90,500,400,10],[560,0,10,100],[640,0,10,100],
                    [560,500,10,100],[640,500,10,100],[1100,260,100,10],[1100,340,100,10],
                    [1100,90,10,100],[710,90,390,10],[1100,410,10,100],[710,500,390,10],
                    [490,210,220,10],[490,220,10,50],[700,220,10,50],[490,380,220,10],
                    [490,330,10,50],[700,330,10,50],[390,170,10,250],[800,170,10,250]]
        Rooms.append(walls1)
        for wall in walls1:
            newWall = Walls(wall[0],wall[1],wall[2],wall[3])
            self.allSprites.add(newWall)
            self.wallSprites.add(newWall)
  
    #Tenn
    def eventHandler(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.play = False
            #Not Python 2.x Compatable: Change chr to uni_char
            if event.type == pygame.KEYDOWN:
                #self.pressed2.append(chr(event.key))
                self.pressed[chr(event.key)] = True
            if event.type == pygame.KEYUP:
                self.pressed[chr(event.key)] = False
                #self.pressed2.remove(chr(event.key))

    #Tenn
    def loop(self):
        while self.play:
            self.eventHandler()
            self.update()
            self.render()
            self.clock.tick(60)

    #Tenn
    def update(self):
        #if "q" in self.pressed2 or ESC in self.pressed2:
        if self.pressed["q"] or self.pressed[ESC]:
            self.play = False
        for player in self.playerSprites:
            pass
        
        
    #Tenn & Aniekan
    def render(self):
        self.screen.fill([255,255,255])
        # == Draw Code ==
        self.initLevel()
        pygame.draw.rect(self.screen, GREY, [0,0,10,10])
        self.wallSprites.draw(self.screen)
        self.playerSprites.draw(self.screen)
        
        # == End Draw Code ==
        pygame.display.flip()

#Tenn
if __name__ == "__main__":
    main = Main()
    main.loop()
    pygame.quit()

